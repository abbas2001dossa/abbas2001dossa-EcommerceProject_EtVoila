

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class signupcheck extends HttpServlet 
{
	
	@SuppressWarnings("null")
	public void doPost( HttpServletRequest req , HttpServletResponse resp ) throws IOException,ServletException
	{
		
		PrintWriter pw = resp.getWriter();
		resp.setContentType("text/html");
		
		//variables of sign up 
		 String name= req.getParameter("username");
		 String email = req.getParameter("logemail");
	     String pass = req.getParameter("logpass");
	     String address = req.getParameter("address");
	     String contact = req.getParameter("contact");
	     
	     
	     
	     
	     
	     
	     try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}
			
			Connection con;
			try {
				con= DriverManager.getConnection("jdbc:mysql:///ecommerce_project_etvolia", "root", "asbnbnassd");
				
				
				if (con == null) {
			         System.out.println("JDBC connection is not established");
			         return;
			    } 
				else 
				{
					
				
			         System.out.println("Congratulations," +  " JDBC connection is established \n");
			         
			        
			         
			         Statement st = con.createStatement();
			         Statement st2 = con.createStatement();

				      String query = "SELECT * FROM customer";

				      ResultSet rs = st.executeQuery(query); 
				      while (rs.next())
				      {
				    	  if (  name.equals(rs.getString(2))   || name.equals(rs.getString(4)) )	  
				    	  {
				    		  System.out.println(" name cannot be same ! ");
				    		  String page = "wrongpassword.html";
				    		  RequestDispatcher dd=req.getRequestDispatcher(page);
				    		  dd.forward(req, resp);
				    		  
				    	  }
				    	  
				      }
				      
				      
				      // find out which entry was last 
				      Statement statement2 = null;
				      statement2 = con.createStatement();
				      String query3 ="select c_id from customer ORDER BY c_id DESC LIMIT 1 ;"    ;
				      ResultSet rs2 = statement2.executeQuery(query3);
				      int customerID = 0;
				      while (rs2.next())
				      {
				    	  customerID = rs2.getInt(1);
				      }
				      
//				      Dint customerID = rs2.getInt("c_id");
		
				      // for the next customer 
				      customerID++; 
				      
				      
				      // put the entry into DB 
				      Statement statement = null;
				      statement = con.createStatement();
				      

				      String query2 = "insert into customer values(" + customerID + ",'" + name + "','" + address
				    		  + "','" + email + "','" + pass + "','" + contact + "');";
 				      statement.execute(query2);
				      
				      
				      
				      // login  successful ! 
					  String page2 = "index.html";
					  resp.sendRedirect(page2);
				      				      
//				      // close JDBC objects
				      rs.close();
				      st.close();
					  con.close();
					 
					  
				}
			
			
			
			
			
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
	    
	     
	    	 
	
	}
	
}


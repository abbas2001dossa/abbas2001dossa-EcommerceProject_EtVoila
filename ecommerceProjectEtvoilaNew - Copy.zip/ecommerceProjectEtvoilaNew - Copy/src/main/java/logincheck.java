
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class logincheck extends HttpServlet 
{
	
	public void doPost( HttpServletRequest req , HttpServletResponse resp ) throws IOException,ServletException
	{
		
		PrintWriter pw = resp.getWriter();
		resp.setContentType("text/html");
		
		 String name= req.getParameter("username");
	     String pass = req.getParameter("logpass");
	     
	     
	     
	     try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}
			
			Connection con;
			try {
				con= DriverManager.getConnection("jdbc:mysql:///ecommerce_project_etvolia", "root", "asbnbnassd");
				
				
				if (con == null) {
			         System.out.println("JDBC connection is not established");
			         return;
			    } 
				else 
				{
					
				
			         System.out.println("Congratulations," +  " JDBC connection is established \n");
			         
			        
			         
			          Statement st = con.createStatement();		        
				      String query = "SELECT * FROM customer";
				      ResultSet rs = st.executeQuery(query); 
				      
				      
				      String qq="select * from Admin";
				      Statement sq = con.createStatement();		        
				      ResultSet rq = sq.executeQuery(qq);
				      rq.next();
				      
				      while (rq.next())
				      {
				    	  if (  name.equals(rq.getString(2))   || name.equals(rq.getString(3)) )	  
				    	  {
				    		  resp.sendRedirect("dashboard.html");
				    		  return;
				    	  }
				      }
				      
				      while (rs.next())
				      {	
				    	  if (  name.equals(rs.getString(2))   || name.equals(rs.getString(4)) )	  
				    	  {
				    		  if ( pass.equals(rs.getString(5))   )
				    		  {
				    			  System.out.println(" Login Successful ! ");
				    			  
				    			  HttpSession session = req.getSession();
				    			  session.setAttribute("customer_id", rs.getInt(1));
				    			  resp.sendRedirect("index.html");
				    			  return; 
				    		  }
				    		  else {
				    			  System.out.println("wrong password ");
				    			  resp.sendRedirect("wrongpassword.html");
				    			  return ;
				    		  }
				    		  
				    	  }
				    	  else { 
				    	  }
				    	  
				      }
				      				      
//				      // close JDBC objects
				      rs.close();
				      st.close();
					  con.close();
					 
					  // login not successful !
					  resp.sendRedirect("wrongpassword.html");
			      
				}
			
			
			
			
			
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
	    
	     
	    	 
	
	}
	
}
